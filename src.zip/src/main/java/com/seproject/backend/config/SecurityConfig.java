package com.seproject.backend.config;

public class SecurityConfig {
    
}
