package com.seproject.backend.repository;

import com.seproject.backend.entity.Teamspace;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamspaceRepository extends JpaRepository<Teamspace, Integer> {
}
