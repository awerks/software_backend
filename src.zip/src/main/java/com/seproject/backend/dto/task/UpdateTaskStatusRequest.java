package com.seproject.backend.dto.task;

import lombok.Data;

@Data
public class UpdateTaskStatusRequest {
    private String status;
}
