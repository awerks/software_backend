package com.seproject.backend.dto;

import lombok.Data;
import lombok.AllArgsConstructor;

@Data
@AllArgsConstructor
public class SuccessResponse {
    private String message;
}
